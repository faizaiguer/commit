var id = { name: "faiza", age: 29, sexe: "femme", profession:"developpeuse web"};

 var toJSON = JSON.stringify(id);
 localStorage.setItem("data_issues", toJSON);

//recevoir des données
 var fromJSON = localStorage.getItem("data_issues");
var obj = JSON.parse(fromJSON);


console.log("coucou");
