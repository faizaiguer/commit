import socket
import threading

bind_ip = "0 0 0 0"
bind_port = 8000

server = socket socket(socket.AF_INET. socket_SOCK_STREAM)
server.bind((bind_ip, bind_port))
server.listen(5)

print "Listening on %s:%d" % (bind_ip,bind_port)

def manage_client(client_socket);
   while true:
       request = client_socket.recv(1024)
       print"Received : %s" % request
       client_socket.send("ACCEPTED!")


while true:
    client.addr = server.accept()
    print"accepted connection from %s:%d" % ( addr[0], addr[1])
    manage_client = threading.thread(target=manage_client.args=(client.))
    manage_client.start()
