import http.server
 
PORT = 4035
server_address = ("localhost", 4035)

server = http.server.HTTPServer
handler = http.server.CGIHTTPRequestHandler
handler.cgi_directories = ["/"]
print("Serveur actif sur le port :", 4035)

httpd = server(server_address, handler)
httpd.serve_forever()